<?php

header('Content-Type: application/json');

$users = [
    [
        "id" => 1,
        "name" => "Bryan",
        "age" => 23,
        "email" => "bryan@gmail.com",
        "status" => "active"
    ],
    [
        "id" => 2,
        "name" => "Juliean",
        "age" => 18,
        "email" => "juliean@gmail.com",
        "status" => "active"
    ],
    [
        "id" => 3,
        "name" => "Elysa",
        "age" => 19,
        "email" => "elysa@gmail.com",
        "status" => "active"
    ]
];

echo json_encode($users);
?>