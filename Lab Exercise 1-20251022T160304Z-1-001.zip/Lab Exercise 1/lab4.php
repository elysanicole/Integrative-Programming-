<?php
header('Content-Type: application/json');


if ($_SERVER["REQUEST_METHOD"] =="POST"){
   $name = $_POST['name'];
   $message = "Welcome, " .htmlspecialchars($name)."!";


   $response = array(
       "status" => "success",
       "message" => $message
   );


   echo json_encode($response);
} else {
   $response = array(
       "status"=>"error",
       "message"=>"Invalid request method."
   );
   echo json_encode($response);
}
?>
