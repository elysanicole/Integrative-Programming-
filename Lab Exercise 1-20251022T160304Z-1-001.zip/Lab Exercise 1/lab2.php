<?php

$jsonString = '{"name": "Bryan", "age": 25, "email": "Bryan@gmail.com"}';


$obj = json_decode($jsonString);


$array = json_decode($jsonString, true);

echo "Object: " . $obj->name . "<br>";
echo "Array: " . $array['email'] . "<br>";
?>