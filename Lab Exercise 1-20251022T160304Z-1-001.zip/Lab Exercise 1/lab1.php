<?php
$student = array(
    "name" => "Juliean",
    "age" => 20,
    "course" => "IT"
);

$json_data = json_encode($student);

echo $json_data;
?>