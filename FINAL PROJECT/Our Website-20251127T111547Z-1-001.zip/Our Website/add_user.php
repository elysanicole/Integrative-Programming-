<?php
session_start();
if(!isset($_SESSION['username'])) header("Location: login.php");

if($_SERVER['REQUEST_METHOD']==='POST'){
    $data = json_decode(file_get_contents('data.json'), true);

    $newId = end($data)['id']+1;
    $filename = '';

    if(isset($_FILES['picture'])){
        $filename = 'uploads/'.basename($_FILES['picture']['name']);
        move_uploaded_file($_FILES['picture']['tmp_name'], $filename);
    }

    $data[] = [
        "id"=>$newId,
        "last_name"=>$_POST['last_name'],
        "first_name"=>$_POST['first_name'],
        "middle_name"=>$_POST['middle_name'],
        "age"=>$_POST['age'],
        "date_of_birth"=>$_POST['dob'],
        "sex"=>$_POST['sex'],
        "status"=>$_POST['status'],
        "email"=>$_POST['email'],
        "number"=>$_POST['number'],
        "address"=>$_POST['address'],
        "course"=>$_POST['course'],
        "picture"=>$filename
    ];

    file_put_contents('data.json', json_encode($data, JSON_PRETTY_PRINT));

    // Log
    $logs = json_decode(file_get_contents('actlogs.json'), true);
    $logs[] = [
        "action" => "add_user",
        "username" => $_SESSION['username'],
        "added_user" => $_POST['first_name'].' '.$_POST['last_name'],
        "timestamp"=>date('Y-m-d H:i:s')
    ];
    file_put_contents('actlogs.json', json_encode($logs, JSON_PRETTY_PRINT));

    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head><title>Add User</title></head>
<body>
<h2>Add New User</h2>
<form method="POST" enctype="multipart/form-data">
    Last Name: <input name="last_name" required><br>
    First Name: <input name="first_name" required><br>
    Middle Name: <input name="middle_name"><br>
    Age: <input type="number" name="age" required><br>
    DOB: <input type="date" name="dob" required><br>
    Sex: <select name="sex"><option>Male</option><option>Female</option></select><br>
    Status: <input name="status"><br>
    Email: <input type="email" name="email" required><br>
    Number: <input name="number"><br>
    Address: <input name="address"><br>
    Course: <input name="course"><br>
    Picture: <input type="file" name="picture"><br><br>
    <input type="submit" value="Add User">
</form>
<a href="index.php">Back</a>
</body>
</html>
