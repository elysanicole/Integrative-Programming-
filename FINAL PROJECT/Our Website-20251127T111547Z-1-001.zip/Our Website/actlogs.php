<?php 
session_start();
if (!isset($_SESSION['username'])) header("Location: login.php");

$filename = 'actlogs.json';

if (!file_exists($filename)) {
    die("Error: Log file '$filename' not found.");
}

$logs = json_decode(file_get_contents($filename), true);

if (!is_array($logs)) {
    die("Error: Failed to load activity logs.");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Activity Logs</title>
<style>
    body {
        margin: 0;
        font-family: Arial, sans-serif;


        background: url('bg.jpg') no-repeat center center fixed;
        background-size: cover;

        animation: fadebg 2s ease-in-out;
    }

    @keyframes fadebg {
        from { opacity: 0; }
        to { opacity: 1; }
    }

    /* GLASS EFFECT CARD */
    .container {
        width: 80%;
        max-width: 900px;
        margin: 50px auto;
        padding: 20px 30px;

        background: rgba(255, 255, 255, 0.25); /* transparent */
        backdrop-filter: blur(12px); /* glass blur */
        -webkit-backdrop-filter: blur(12px);
        
        border-radius: 15px;
        border: 1px solid rgba(255, 255, 255, 0.35);
        box-shadow: 0 4px 30px rgba(0, 0, 0, 0.2);

        animation: fadein 1s ease-in-out;
    }

    @keyframes fadein {
        from { transform: translateY(-20px); opacity: 0; }
        to { transform: translateY(0); opacity: 1; }
    }

    h2 {
        text-align: center;
        margin-bottom: 20px;
        color: #fff;
        font-size: 28px;
        letter-spacing: 1px;
        text-shadow: 0 1px 3px rgba(0,0,0,0.3);
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 10px;
    }

    th {
        background: rgba(0, 123, 255, 0.85);
        color: white;
        padding: 12px;
        font-size: 16px;
        letter-spacing: .5px;
    }

    td {
        padding: 12px;
        font-size: 15px;
        text-align: center;
        background: rgba(255, 255, 255, 0.85);
        border-bottom: 1px solid rgba(255,255,255,0.3);
    }

    tr:hover td {
        background: rgba(255, 255, 255, 0.95);
        transition: 0.3s;
    }

    .back-btn {
        display: block;
        width: 100px;
        text-align: center;
        margin: 20px auto 0;
        padding: 10px;
        background: rgba(0, 123, 255, 0.85);
        color: white;
        text-decoration: none;
        border-radius: 6px;
        font-size: 16px;
        transition: 0.3s;
    }

    .back-btn:hover {
        background: rgba(0, 86, 179, 0.85);
    }
</style>
</head>
<body>

<div class="container">
    <h2>Activity Logs</h2>

    <table>
        <tr>
            <th>Action</th>
            <th>Username</th>
            <th>Details</th>
            <th>Timestamp</th>
        </tr>

        <?php foreach ($logs as $log): ?>
        <tr>
            <td><?= $log['action']; ?></td>
            <td><?= $log['username']; ?></td>
            <td>
                <?php
                    if (isset($log['added_user'])) echo "Added user: " . $log['added_user'];
                    else if (isset($log['edited_user'])) echo "Edited user: " . $log['edited_user'];
                    else if (isset($log['deleted_user'])) echo "Deleted user: " . $log['deleted_user'];
                    else echo "-";
                ?>
            </td>
            <td><?= $log['timestamp']; ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <a href="index.php" class="back-btn">Back</a>
</div>

</body>
</html>
