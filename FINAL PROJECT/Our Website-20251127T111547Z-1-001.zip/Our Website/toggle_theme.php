<?php
$theme = json_decode(file_get_contents('theme.json'), true);
$theme['theme'] = $theme['theme'] === 'dark' ? 'light' : 'dark';
file_put_contents('theme.json', json_encode($theme, JSON_PRETTY_PRINT));
header("Location: index.php");
exit;
