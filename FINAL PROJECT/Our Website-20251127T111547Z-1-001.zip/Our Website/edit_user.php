<?php
session_start();
if(!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Load users
$data = json_decode(file_get_contents('data.json'), true);

// Get user ID
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Hanapin ang user
$userFound = null;
foreach($data as $key => $user){
    if($user['id'] === $id){
        $userFound = $user;
        $userKey = $key;
        break;
    }
}

if(!$userFound){
    echo "User not found!";
    exit;
}

// Process form submission
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $filename = $userFound['picture']; // keep old picture if none uploaded
    if(isset($_FILES['picture']) && $_FILES['picture']['name'] != ''){
        $filename = 'uploads/'.basename($_FILES['picture']['name']);
        move_uploaded_file($_FILES['picture']['tmp_name'], $filename);
    }

    // Update data
    $data[$userKey] = [
        "id" => $id,
        "last_name" => $_POST['last_name'],
        "first_name" => $_POST['first_name'],
        "middle_name" => $_POST['middle_name'],
        "age" => $_POST['age'],
        "date_of_birth" => $_POST['dob'],
        "sex" => $_POST['sex'],
        "status" => $_POST['status'],
        "email" => $_POST['email'],
        "number" => $_POST['number'],
        "address" => $_POST['address'],
        "course" => $_POST['course'],
        "picture" => $filename
    ];

    // Save updated JSON
    file_put_contents('data.json', json_encode($data, JSON_PRETTY_PRINT));

    // Log
    $logs = json_decode(file_get_contents('actlogs.json'), true);
    $logs[] = [
        "action" => "edit_user",
        "username" => $_SESSION['username'],
        "edited_user" => $_POST['first_name'].' '.$_POST['last_name'],
        "timestamp" => date('Y-m-d H:i:s')
    ];
    file_put_contents('actlogs.json', json_encode($logs, JSON_PRETTY_PRINT));

    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit User</title>
</head>
<body>
<h2>Edit User</h2>
<form method="POST" enctype="multipart/form-data">
    Last Name: <input name="last_name" value="<?php echo htmlspecialchars($userFound['last_name']); ?>" required><br>
    First Name: <input name="first_name" value="<?php echo htmlspecialchars($userFound['first_name']); ?>" required><br>
    Middle Name: <input name="middle_name" value="<?php echo htmlspecialchars($userFound['middle_name']); ?>"><br>
    Age: <input type="number" name="age" value="<?php echo htmlspecialchars($userFound['age']); ?>" required><br>
    DOB: <input type="date" name="dob" value="<?php echo htmlspecialchars($userFound['date_of_birth']); ?>" required><br>
    Sex: <select name="sex">
        <option <?php if($userFound['sex']=='Male') echo 'selected'; ?>>Male</option>
        <option <?php if($userFound['sex']=='Female') echo 'selected'; ?>>Female</option>
    </select><br>
    Status: <input name="status" value="<?php echo htmlspecialchars($userFound['status']); ?>"><br>
    Email: <input type="email" name="email" value="<?php echo htmlspecialchars($userFound['email']); ?>" required><br>
    Number: <input name="number" value="<?php echo htmlspecialchars($userFound['number']); ?>"><br>
    Address: <input name="address" value="<?php echo htmlspecialchars($userFound['address']); ?>"><br>
    Course: <input name="course" value="<?php echo htmlspecialchars($userFound['course']); ?>"><br>
    Picture: <input type="file" name="picture"><br><br>
    <input type="submit" value="Update User">
</form>
<a href="index.php">Back</a>
</body>
</html>
