<?php
session_start();

// Siguraduhin naka-login
if(!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

if(isset($_GET['id'])){
    $id = intval($_GET['id']);

    // Load existing users
    $data = json_decode(file_get_contents('data.json'), true);

    // Hanapin ang user at i-delete
    $deletedUser = '';
    foreach($data as $key => $user){
        if($user['id'] === $id){
            $deletedUser = $user['first_name'].' '.$user['last_name'];
            unset($data[$key]);
            break; // Isa lang ang ide-delete
        }
    }

    // I-save ang updated data
    file_put_contents('data.json', json_encode(array_values($data), JSON_PRETTY_PRINT));

    // Log ang deletion
    $logs = json_decode(file_get_contents('actlogs.json'), true);
    $logs[] = [
        "action" => "delete_user",
        "username" => $_SESSION['username'],
        "deleted_user" => $deletedUser,
        "timestamp" => date('Y-m-d H:i:s')
    ];
    file_put_contents('actlogs.json', json_encode($logs, JSON_PRETTY_PRINT));

    // Redirect pabalik sa index
    header("Location: index.php");
    exit;

} else {
    echo "No user ID provided!";
}
?>
