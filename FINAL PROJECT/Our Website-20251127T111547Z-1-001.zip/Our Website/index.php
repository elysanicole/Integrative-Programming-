<?php
session_start();
if(!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Load theme
$theme = json_decode(file_get_contents('theme.json'), true);
$Theme = $theme['theme'] ?? 'light';

$users = json_decode(file_get_contents('data.json'), true);
?>
<!DOCTYPE html>
<html>
<head>
<title>Our Website</title>
<style>
body {
    font-family: Arial, sans-serif;
    background-image: url('bg.jpg');
    background-size: 120% 120%;
    background-repeat: no-repeat;
    background-position: center;
    color: <?php echo $Theme === 'dark' ? '#fff' : '#000'; ?>;
    margin: 0;
    padding: 0;
    transition: color 0.5s, background-color 0.5s;
    animation: bgZoom 20s ease-in-out infinite alternate;
}

/* Background overlay */
body::before {
    content: '';
    position: fixed;
    top:0; left:0;
    width:100%; height:100%;
    background-color: <?php echo $Theme === 'dark' ? 'rgba(0,0,0,0.6)' : 'rgba(255,255,255,0.3)'; ?>;
    z-index: -1;
    transition: background-color 0.5s;
}

/* Background zoom animation */
@keyframes bgZoom {
    0% { background-size: 120% 120%; }
    50% { background-size: 100% 100%; }
    100% { background-size: 120% 120%; }
}

header {
    text-align: center;
    padding: 20px;
    transition: all 0.5s;
}

.user-actions {
    text-align: center;
    margin-bottom: 20px;
}

.user-card {
    max-width: 600px;
    margin: 20px auto;
    padding: 20px;
    border: 1px solid <?php echo $Theme === 'dark' ? '#444' : '#ccc'; ?>;
    border-radius: 10px;
    background-color: <?php echo $Theme === 'dark' ? 'rgba(0,0,0,0.5)' : 'rgba(255,255,255,0.85)'; ?>;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    backdrop-filter: blur(5px);
    transition: all 0.3s;
}

.user-card:hover {
    transform: scale(1.02);
}

.user-card p {
    margin: 8px 0;
    line-height: 1.5;
}

a {
    text-decoration: none;
    color: <?php echo $Theme === 'dark' ? '#4fc3f7' : 'blue'; ?>;
    font-weight: bold;
    transition: color 0.3s;
}

a.delete-link { color: red; margin-left: 10px; }
a.edit-link { color: green; margin-left: 10px; }

button {
    padding: 6px 12px;
    margin: 10px 0;
    cursor: pointer;
    border-radius: 5px;
    border: none;
    background-color: <?php echo $Theme === 'dark' ? '#4fc3f7' : '#007bff'; ?>;
    color: #fff;
    font-weight: bold;
    transition: opacity 0.3s;
}

button:hover { opacity: 0.8; }

h1 { margin-bottom: 10px; }
</style>
</head>
<body>

<header>
    <h1>Our Website</h1>
    <div class="user-actions">
        Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?> | 
        <a href="logout.php">Logout</a> | 
        <a href="add_user.php">Add User</a>
    </div>
    <button onclick="window.location='toggle_theme.php'">Toggle Dark/Light Mode</button>
</header>

<?php foreach($users as $u): ?>
<div class="user-card">
    <p>
        <strong>
        <a href="user.php?id=<?php echo $u['id']; ?>">
            <?php echo htmlspecialchars($u['last_name'].', '.$u['first_name'].' '.$u['middle_name']); ?>
        </a>
        </strong>
        <a class="edit-link" href="edit_user.php?id=<?php echo $u['id']; ?>">Edit</a>
        <a class="delete-link" href="delete_user.php?id=<?php echo $u['id']; ?>" 
           onclick="return confirm('Are you sure you want to delete <?php echo htmlspecialchars($u['first_name'].' '.$u['last_name']); ?>?');">
           Delete
        </a>
    </p>
    <p><strong>Email:</strong> <?php echo htmlspecialchars($u['email']); ?></p>
    <p><strong>Age:</strong> <?php echo htmlspecialchars($u['age']); ?></p>
    <p><strong>Course:</strong> <?php echo htmlspecialchars($u['course']); ?></p>
</div>
<?php endforeach; ?>

</body>
</html>
