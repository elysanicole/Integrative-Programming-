<?php
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$users = json_decode(file_get_contents('data.json'), true);
$userFound = null;
foreach ($users as $user) {
    if ($user['id'] === $id) { $userFound = $user; break; }
}
if (!$userFound) { echo "<h2 style='text-align:center;'>User not found</h2><p style='text-align:center;'><a href='index.php'>Back to list</a></p>"; exit; }

$theme = json_decode(file_get_contents('theme.json'), true);
$Theme = $theme['theme'] ?? 'light';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo htmlspecialchars($userFound['last_name'] . ', ' . $userFound['first_name']); ?> - Profile</title>
<style>
body {
    font-family: Arial, sans-serif;
    margin: 0; padding: 0;
    background-image: url('bg.jpg');
    background-size: 120% 120%;
    background-repeat: no-repeat;
    background-position: center;
    color: <?php echo $Theme === 'dark' ? '#fff' : '#000'; ?>;
    transition: color 0.5s, background-color 0.5s;
    animation: bgZoom 20s ease-in-out infinite alternate;
}
body::before {
    content: '';
    position: fixed;
    top:0; left:0;
    width:100%; height:100%;
    background-color: <?php echo $Theme === 'dark' ? 'rgba(0,0,0,0.6)' : 'rgba(255,255,255,0.3)'; ?>;
    z-index: -1;
    transition: background-color 0.5s;
}
@keyframes bgZoom {
    0% { background-size: 120% 120%; }
    50% { background-size: 100% 100%; }
    100% { background-size: 120% 120%; }
}

.profile-container {
    max-width: 550px;
    margin: 80px auto;
    padding: 30px;
    border-radius: 15px;
    background-color: <?php echo $Theme === 'dark' ? 'rgba(0,0,0,0.5)' : 'rgba(255,255,255,0.3)'; ?>;
    text-align: center;
    box-shadow: 0 4px 15px rgba(0,0,0,0.3);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    transition: all 0.5s;
}

.profile-container img {
    width: 150px; height: 150px;
    border-radius: 50%;
    margin-bottom: 20px;
    object-fit: cover;
    border: 3px solid <?php echo $Theme === 'dark' ? '#fff' : '#000'; ?>;
    transition: transform 0.3s;
}
.profile-container img:hover { transform: scale(1.05); }

h2 { margin-bottom: 20px; }

.profile-details {
    text-align: left;
    margin: 0 auto;
    max-width: 400px;
}

.profile-details p { margin: 8px 0; font-size: 16px; }

a.back-link {
    display: inline-block;
    margin-top: 20px;
    font-weight: bold;
    color: <?php echo $Theme === 'dark' ? '#4fc3f7' : 'blue'; ?>;
    text-decoration: none;
    padding: 6px 12px;
    border-radius: 5px;
    border: 1px solid <?php echo $Theme === 'dark' ? '#4fc3f7' : 'blue'; ?>;
    transition: all 0.3s;
}
a.back-link:hover { background-color: <?php echo $Theme === 'dark' ? '#4fc3f7' : 'blue'; ?>; color: #fff; }
</style>
</head>
<body>

<div class="profile-container">
    <img src="<?php echo htmlspecialchars($userFound['picture']); ?>" 
         alt="<?php echo htmlspecialchars($userFound['first_name']); ?>">

    <h2><?php echo htmlspecialchars($userFound['last_name'] . ', ' . $userFound['first_name'] . ' ' . $userFound['middle_name']); ?></h2>

    <div class="profile-details">
        <p><strong>Date of Birth:</strong> <?php echo htmlspecialchars($userFound['date_of_birth']); ?></p>
        <p><strong>Age:</strong> <?php echo htmlspecialchars($userFound['age']); ?></p>
        <p><strong>Sex:</strong> <?php echo htmlspecialchars($userFound['sex']); ?></p>
        <p><strong>Status:</strong> <?php echo htmlspecialchars($userFound['status']); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($userFound['email']); ?></p>
        <p><strong>Contact Number:</strong> <?php echo htmlspecialchars($userFound['number']); ?></p>
        <p><strong>Address:</strong> <?php echo htmlspecialchars($userFound['address']); ?></p>
        <p><strong>Course:</strong> <?php echo htmlspecialchars($userFound['course']); ?></p>
    </div>

    <a class="back-link" href="index.php">Back to list</a>
</div>

</body>
</html>
