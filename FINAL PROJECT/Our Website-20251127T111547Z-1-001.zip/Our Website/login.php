<?php  
session_start();

if(isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}

$error = '';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $users = json_decode(file_get_contents('login.json'), true);

    foreach($users as $user) {
        if($user['username'] === $username && $user['password'] === $password) {
            $_SESSION['username'] = $username;

            // Log login
            $logs = json_decode(file_get_contents('actlogs.json'), true);
            $logs[] = [
                "action" => "login",
                "username" => $username,
                "timestamp" => date('Y-m-d H:i:s')
            ];
            file_put_contents('actlogs.json', json_encode($logs, JSON_PRETTY_PRINT));

            header("Location: index.php");
            exit;
        }
    }
    $error = "Invalid username or password.";
}

// Load theme
$theme = json_decode(file_get_contents('theme.json'), true);
$Theme = $theme['theme'] ?? 'light';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login</title>
<style>
body {
    font-family: Arial, sans-serif;
    margin: 0; 
    padding: 0;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background-image: url('bg.jpg');
    background-size: cover;
    background-position: center;
    color: <?php echo $Theme === 'dark' ? '#fff' : '#000'; ?>;
    flex-direction: column;
    text-align: center;
}

/* Overlay for readability */
body::before {
    content: '';
    position: fixed;
    top:0; left:0;
    width:100%; height:100%;
    background-color: <?php echo $Theme === 'dark' ? 'rgba(0,0,0,0.6)' : 'rgba(255,255,255,0.3)'; ?>;
    z-index: -1;
}

h1 {
    margin-bottom: 30px;
    font-size: 28px;
    color: black; /* <-- black color for the welcome message */
}

form {
    display: flex;
    flex-direction: column;
    width: 300px;
}

form input[type="text"],
form input[type="password"],
form input[type="submit"] {
    padding: 10px 12px;
    margin: 10px 0;
    border-radius: 5px;
    border: 1px solid <?php echo $Theme === 'dark' ? '#444' : '#ccc'; ?>;
    font-size: 16px;
    outline: none;
    transition: all 0.3s;
}

form input[type="text"]:focus,
form input[type="password"]:focus {
    border-color: <?php echo $Theme === 'dark' ? '#4fc3f7' : '#007bff'; ?>;
    box-shadow: 0 0 5px <?php echo $Theme === 'dark' ? '#4fc3f7' : '#007bff'; ?>;
}

form input[type="submit"] {
    border: none;
    background-color: <?php echo $Theme === 'dark' ? '#4fc3f7' : '#007bff'; ?>;
    color: #fff;
    font-weight: bold;
    cursor: pointer;
}

form input[type="submit"]:hover {
    opacity: 0.85;
}

.error-message {
    color: red;
    text-align: center;
    font-size: 14px;
}
</style>
</head>
<body>

<h1>Welcome to Our Website!</h1>

<form method="POST">
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <input type="submit" value="Login">
    <?php if($error): ?>
        <p class="error-message"><?php echo $error; ?></p>
    <?php endif; ?>
</form>

</body>
</html>
